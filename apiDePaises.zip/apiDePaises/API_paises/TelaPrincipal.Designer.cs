﻿namespace API_paises
{
    partial class TelaPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaPrincipal));
            pictureBox1 = new PictureBox();
            txtResposta2 = new TextBox();
            txtResposta3 = new TextBox();
            lbpergunta2 = new Label();
            lbpergunta3 = new Label();
            button1 = new Button();
            label1 = new Label();
            txtResposta4 = new TextBox();
            buttonRandom = new Button();
            buttonBuscarPorIdioma = new Button();
            txtIdioma = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtResposta8 = new TextBox();
            label4 = new Label();
            label5 = new Label();
            txtResposta7 = new TextBox();
            txtResposta6 = new TextBox();
            txtResposta5 = new TextBox();
            label6 = new Label();
            txtRespostas1 = new TextBox();
            lbpergunta1 = new Label();
            label7 = new Label();
            textBox5 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(58, 50);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(309, 207);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // txtResposta2
            // 
            txtResposta2.Location = new Point(443, 147);
            txtResposta2.Margin = new Padding(3, 4, 3, 4);
            txtResposta2.Name = "txtResposta2";
            txtResposta2.ReadOnly = true;
            txtResposta2.Size = new Size(114, 27);
            txtResposta2.TabIndex = 2;
            // 
            // txtResposta3
            // 
            txtResposta3.Location = new Point(443, 217);
            txtResposta3.Margin = new Padding(3, 4, 3, 4);
            txtResposta3.Name = "txtResposta3";
            txtResposta3.ReadOnly = true;
            txtResposta3.Size = new Size(114, 27);
            txtResposta3.TabIndex = 3;
            // 
            // lbpergunta2
            // 
            lbpergunta2.AutoSize = true;
            lbpergunta2.BackColor = Color.Transparent;
            lbpergunta2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbpergunta2.ForeColor = Color.DarkRed;
            lbpergunta2.Location = new Point(443, 123);
            lbpergunta2.Name = "lbpergunta2";
            lbpergunta2.Size = new Size(63, 23);
            lbpergunta2.TabIndex = 5;
            lbpergunta2.Text = "Capital";
            // 
            // lbpergunta3
            // 
            lbpergunta3.AutoSize = true;
            lbpergunta3.BackColor = Color.Transparent;
            lbpergunta3.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            lbpergunta3.ForeColor = Color.DarkRed;
            lbpergunta3.Location = new Point(443, 193);
            lbpergunta3.Name = "lbpergunta3";
            lbpergunta3.Size = new Size(89, 23);
            lbpergunta3.TabIndex = 6;
            lbpergunta3.Text = "População";
            // 
            // button1
            // 
            button1.BackColor = Color.Lime;
            button1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(530, 365);
            button1.Name = "button1";
            button1.Size = new Size(121, 35);
            button1.TabIndex = 7;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            label1.ForeColor = Color.DarkRed;
            label1.Location = new Point(443, 264);
            label1.Name = "label1";
            label1.Size = new Size(45, 23);
            label1.TabIndex = 9;
            label1.Text = "Área";
            // 
            // txtResposta4
            // 
            txtResposta4.Location = new Point(443, 288);
            txtResposta4.Margin = new Padding(3, 4, 3, 4);
            txtResposta4.Name = "txtResposta4";
            txtResposta4.ReadOnly = true;
            txtResposta4.Size = new Size(114, 27);
            txtResposta4.TabIndex = 8;
            // 
            // buttonRandom
            // 
            buttonRandom.BackColor = Color.Yellow;
            buttonRandom.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonRandom.Location = new Point(394, 430);
            buttonRandom.Name = "buttonRandom";
            buttonRandom.Size = new Size(94, 37);
            buttonRandom.TabIndex = 10;
            buttonRandom.Text = "Random";
            buttonRandom.UseVisualStyleBackColor = false;
            buttonRandom.Click += buttonRandom_Click;
            // 
            // buttonBuscarPorIdioma
            // 
            buttonBuscarPorIdioma.BackColor = Color.Blue;
            buttonBuscarPorIdioma.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonBuscarPorIdioma.Location = new Point(58, 411);
            buttonBuscarPorIdioma.Name = "buttonBuscarPorIdioma";
            buttonBuscarPorIdioma.Size = new Size(111, 29);
            buttonBuscarPorIdioma.TabIndex = 11;
            buttonBuscarPorIdioma.Text = "Buscar";
            buttonBuscarPorIdioma.UseVisualStyleBackColor = false;
            buttonBuscarPorIdioma.Click += buttonBuscarPorIdioma_Click;
            // 
            // txtIdioma
            // 
            txtIdioma.Location = new Point(175, 411);
            txtIdioma.Name = "txtIdioma";
            txtIdioma.PlaceholderText = "Digite o idioma";
            txtIdioma.Size = new Size(169, 27);
            txtIdioma.TabIndex = 12;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.WhiteSmoke;
            label2.Location = new Point(58, 365);
            label2.Name = "label2";
            label2.Size = new Size(286, 23);
            label2.TabIndex = 13;
            label2.Text = "Países que falam o idioma digitado";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            label3.ForeColor = Color.DarkRed;
            label3.Location = new Point(617, 264);
            label3.Name = "label3";
            label3.Size = new Size(63, 23);
            label3.TabIndex = 21;
            label3.Text = "Idioma";
            // 
            // txtResposta8
            // 
            txtResposta8.Location = new Point(617, 288);
            txtResposta8.Margin = new Padding(3, 4, 3, 4);
            txtResposta8.Name = "txtResposta8";
            txtResposta8.ReadOnly = true;
            txtResposta8.Size = new Size(114, 27);
            txtResposta8.TabIndex = 20;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            label4.ForeColor = Color.DarkRed;
            label4.Location = new Point(617, 193);
            label4.Name = "label4";
            label4.Size = new Size(64, 23);
            label4.TabIndex = 19;
            label4.Text = "Moeda";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.DarkRed;
            label5.Location = new Point(617, 123);
            label5.Name = "label5";
            label5.Size = new Size(63, 23);
            label5.TabIndex = 18;
            label5.Text = "Região";
            // 
            // txtResposta7
            // 
            txtResposta7.Location = new Point(617, 217);
            txtResposta7.Margin = new Padding(3, 4, 3, 4);
            txtResposta7.Name = "txtResposta7";
            txtResposta7.ReadOnly = true;
            txtResposta7.Size = new Size(114, 27);
            txtResposta7.TabIndex = 16;
            // 
            // txtResposta6
            // 
            txtResposta6.Location = new Point(617, 147);
            txtResposta6.Margin = new Padding(3, 4, 3, 4);
            txtResposta6.Name = "txtResposta6";
            txtResposta6.ReadOnly = true;
            txtResposta6.Size = new Size(114, 27);
            txtResposta6.TabIndex = 15;
            // 
            // txtResposta5
            // 
            txtResposta5.Location = new Point(617, 74);
            txtResposta5.Margin = new Padding(3, 4, 3, 4);
            txtResposta5.Name = "txtResposta5";
            txtResposta5.ReadOnly = true;
            txtResposta5.Size = new Size(114, 27);
            txtResposta5.TabIndex = 14;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.DarkRed;
            label6.Location = new Point(617, 50);
            label6.Name = "label6";
            label6.Size = new Size(87, 23);
            label6.TabIndex = 22;
            label6.Text = "Subregião";
            // 
            // txtRespostas1
            // 
            txtRespostas1.Location = new Point(193, 287);
            txtRespostas1.Margin = new Padding(3, 4, 3, 4);
            txtRespostas1.Name = "txtRespostas1";
            txtRespostas1.PlaceholderText = "Resposta";
            txtRespostas1.Size = new Size(174, 27);
            txtRespostas1.TabIndex = 1;
            // 
            // lbpergunta1
            // 
            lbpergunta1.AutoSize = true;
            lbpergunta1.BackColor = Color.Transparent;
            lbpergunta1.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lbpergunta1.ForeColor = Color.WhiteSmoke;
            lbpergunta1.Location = new Point(58, 288);
            lbpergunta1.Name = "lbpergunta1";
            lbpergunta1.Size = new Size(121, 23);
            lbpergunta1.TabIndex = 4;
            lbpergunta1.Text = "Nome do país:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.DarkRed;
            label7.Location = new Point(443, 50);
            label7.Name = "label7";
            label7.Size = new Size(95, 23);
            label7.TabIndex = 24;
            label7.Text = "Continente";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(443, 74);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.ReadOnly = true;
            textBox5.Size = new Size(114, 27);
            textBox5.TabIndex = 23;
            // 
            // TelaPrincipal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(806, 544);
            Controls.Add(label7);
            Controls.Add(textBox5);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(txtResposta8);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(txtResposta7);
            Controls.Add(txtResposta6);
            Controls.Add(txtResposta5);
            Controls.Add(label2);
            Controls.Add(txtIdioma);
            Controls.Add(buttonBuscarPorIdioma);
            Controls.Add(buttonRandom);
            Controls.Add(label1);
            Controls.Add(txtResposta4);
            Controls.Add(button1);
            Controls.Add(lbpergunta3);
            Controls.Add(lbpergunta2);
            Controls.Add(lbpergunta1);
            Controls.Add(txtResposta3);
            Controls.Add(txtResposta2);
            Controls.Add(txtRespostas1);
            Controls.Add(pictureBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "TelaPrincipal";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox txtResposta2;
        private TextBox txtResposta3;
        private Label lbpergunta2;
        private Label lbpergunta3;
        private Button button1;
        private Label label1;
        private TextBox txtResposta4;
        private Button buttonRandom;
        private Button buttonBuscarPorIdioma;
        private TextBox txtIdioma;
        private Label label2;
        private Label label3;
        private TextBox txtResposta8;
        private Label label4;
        private Label label5;
        private TextBox txtResposta7;
        private TextBox txtResposta6;
        private TextBox txtResposta5;
        private Label label6;
        private TextBox txtRespostas1;
        private Label lbpergunta1;
        private Label label7;
        private TextBox textBox5;
    }
}
