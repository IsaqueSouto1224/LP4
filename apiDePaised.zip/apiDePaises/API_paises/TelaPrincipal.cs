using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;

namespace API_paises
{
    public partial class TelaPrincipal : Form
    {
        public TelaPrincipal()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string pais = txtRespostas1.Text.Trim(); // Remover espa�os em branco
            
            if (string.IsNullOrEmpty(pais))
            {
                MessageBox.Show("Por favor, insira o nome de um pa�s.");
                return; // Retorna se o campo estiver vazio
            }

            string url = $"https://restcountries.com/v3.1/name/{pais}";

            using (var client = new HttpClient())
            {
                try
                {
                    var resposta = await client.GetStringAsync(url);
                    var dados = JArray.Parse(resposta);

                    var nome = dados[0]["name"]["common"].ToString();
                    var capital = dados[0]["capital"]?.First?.ToString() ?? "Sem capital";
                    var populacao = dados[0]["population"].ToString();
                    var area = dados[0]["area"]?.ToString() ?? "Sem �rea";


                    txtResposta2.Text = $"{capital}";
                    txtResposta3.Text = $"{populacao}";
                    txtResposta4.Text = $"{area} km�";

                    var bandeiraUrl = dados[0]["flags"]["png"].ToString();
                    pictureBox1.Load(bandeiraUrl);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

                }
                catch (HttpRequestException)
                {
                    MessageBox.Show("Erro: N�o foi poss�vel conectar ao servidor.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
            }
        }

        private void lbResultado_Click(object sender, EventArgs e)
        {
            // A��o a ser tomada ao clicar no Label (se necess�rio)
        }
    }
}
