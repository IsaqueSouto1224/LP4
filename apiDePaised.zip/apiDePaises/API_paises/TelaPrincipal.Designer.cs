﻿namespace API_paises
{
    partial class TelaPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaPrincipal));
            pictureBox1 = new PictureBox();
            txtRespostas1 = new TextBox();
            txtResposta2 = new TextBox();
            txtResposta3 = new TextBox();
            lbpergunta1 = new Label();
            lbpergunta2 = new Label();
            lbpergunta3 = new Label();
            button1 = new Button();
            label1 = new Label();
            txtResposta4 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(57, 107);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(309, 183);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // txtRespostas1
            // 
            txtRespostas1.Location = new Point(443, 74);
            txtRespostas1.Margin = new Padding(3, 4, 3, 4);
            txtRespostas1.Name = "txtRespostas1";
            txtRespostas1.PlaceholderText = "Resposta";
            txtRespostas1.Size = new Size(114, 27);
            txtRespostas1.TabIndex = 1;
            // 
            // txtResposta2
            // 
            txtResposta2.Location = new Point(443, 166);
            txtResposta2.Margin = new Padding(3, 4, 3, 4);
            txtResposta2.Name = "txtResposta2";
            txtResposta2.PlaceholderText = "Resposta";
            txtResposta2.Size = new Size(114, 27);
            txtResposta2.TabIndex = 2;
            // 
            // txtResposta3
            // 
            txtResposta3.Location = new Point(443, 236);
            txtResposta3.Margin = new Padding(3, 4, 3, 4);
            txtResposta3.Name = "txtResposta3";
            txtResposta3.PlaceholderText = "Resposta";
            txtResposta3.Size = new Size(114, 27);
            txtResposta3.TabIndex = 3;
            // 
            // lbpergunta1
            // 
            lbpergunta1.AutoSize = true;
            lbpergunta1.Location = new Point(443, 50);
            lbpergunta1.Name = "lbpergunta1";
            lbpergunta1.Size = new Size(103, 20);
            lbpergunta1.TabIndex = 4;
            lbpergunta1.Text = "Nome do país";
            // 
            // lbpergunta2
            // 
            lbpergunta2.AutoSize = true;
            lbpergunta2.Location = new Point(443, 142);
            lbpergunta2.Name = "lbpergunta2";
            lbpergunta2.Size = new Size(56, 20);
            lbpergunta2.TabIndex = 5;
            lbpergunta2.Text = "Capital";
            // 
            // lbpergunta3
            // 
            lbpergunta3.AutoSize = true;
            lbpergunta3.Location = new Point(443, 212);
            lbpergunta3.Name = "lbpergunta3";
            lbpergunta3.Size = new Size(78, 20);
            lbpergunta3.TabIndex = 6;
            lbpergunta3.Text = "População";
            // 
            // button1
            // 
            button1.BackColor = Color.Lime;
            button1.Location = new Point(443, 404);
            button1.Name = "button1";
            button1.Size = new Size(114, 29);
            button1.TabIndex = 7;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(443, 283);
            label1.Name = "label1";
            label1.Size = new Size(40, 20);
            label1.TabIndex = 9;
            label1.Text = "Área";
            // 
            // txtResposta4
            // 
            txtResposta4.Location = new Point(443, 307);
            txtResposta4.Margin = new Padding(3, 4, 3, 4);
            txtResposta4.Name = "txtResposta4";
            txtResposta4.PlaceholderText = "Resposta";
            txtResposta4.Size = new Size(114, 27);
            txtResposta4.TabIndex = 8;
            // 
            // TelaPrincipal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(609, 544);
            Controls.Add(label1);
            Controls.Add(txtResposta4);
            Controls.Add(button1);
            Controls.Add(lbpergunta3);
            Controls.Add(lbpergunta2);
            Controls.Add(lbpergunta1);
            Controls.Add(txtResposta3);
            Controls.Add(txtResposta2);
            Controls.Add(txtRespostas1);
            Controls.Add(pictureBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "TelaPrincipal";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox txtRespostas1;
        private TextBox txtResposta2;
        private TextBox txtResposta3;
        private Label lbpergunta1;
        private Label lbpergunta2;
        private Label lbpergunta3;
        private Button button1;
        private Label label1;
        private TextBox txtResposta4;
    }
}
